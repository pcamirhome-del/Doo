// src/services/apiClient.ts
import { AppItem, Platform } from '../types/app';

const API_BASE_URL = 'http://localhost:3000/api';

export const apiClient = {
  /**
   * Fetches real-time search suggestions with thumbnails
   */
  async getAutocomplete(query: string, platform: Platform): Promise<AppItem[]> {
    if (!query) return [];
    try {
      const response = await fetch(`${API_BASE_URL}/autocomplete?q=${encodeURIComponent(query)}&platform=${platform}`);
      const json = await response.json();
      return json.success ? json.data : [];
    } catch (error) {
      console.error('Autocomplete Error:', error);
      return [];
    }
  },

  /**
   * Performs a deep search across selected platform stores
   */
  async searchApps(query: string, platform: Platform): Promise<AppItem[]> {
    if (!query) return [];
    try {
      const response = await fetch(`${API_BASE_URL}/search?q=${encodeURIComponent(query)}&platform=${platform}`);
      const json = await response.json();
      return json.success ? json.data : [];
    } catch (error) {
      console.error('Search API Error:', error);
      return [];
    }
  },

  /**
   * Fetches 15 items for the dynamic homepage carousels
   */
  async getCarousel(category: 'social' | 'editing', platform: Platform): Promise<AppItem[]> {
    try {
      const response = await fetch(`${API_BASE_URL}/carousel?category=${category}&platform=${platform}`);
      const json = await response.json();
      return json.success ? json.data : [];
    } catch (error) {
      console.error('Carousel API Error:', error);
      return [];
    }
  }
};