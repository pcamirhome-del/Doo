import express, { Request, Response } from 'express';
import cors from 'cors';
import axios from 'axios';
import gplay from 'google-play-scraper';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// ==========================================
// 1. iOS (iPhone) Scraping Logic (App Store Official API)
// ==========================================
const searchIOS = async (query: string, limit: number = 15) => {
  try {
    const response = await axios.get(`https://itunes.apple.com/search`, {
      params: { term: query, entity: 'software', limit }
    });
    return response.data.results.map((app: any) => ({
      id: app.trackId.toString(),
      name: app.trackName,
      developer: app.artistName,
      thumbnail: app.artworkUrl512,
      downloadUrl: app.trackViewUrl,
      platform: 'ios',
      isFOSS: false
    }));
  } catch (error) {
    console.error('iOS Search Error:', error);
    return [];
  }
};

// ==========================================
// 2. Android Scraping Logic (Google Play API)
// ==========================================
const searchAndroid = async (query: string, limit: number = 15) => {
  try {
    const results = await gplay.search({ term: query, num: limit });
    return results.map((app) => ({
      id: app.appId,
      name: app.title,
      developer: app.developer,
      thumbnail: app.icon,
      downloadUrl: app.url,
      platform: 'android',
      isFOSS: false
    }));
  } catch (error) {
    console.error('Android Search Error:', error);
    return [];
  }
};

// ==========================================
// 3. PC (Windows Winget / Open Source Repositories)
// ==========================================
const searchPC = async (query: string) => {
  // In a production scenario, this queries Winget.run API or GitHub REST API.
  // We simulate a robust response returning the software and FOSS alternatives.
  return [
    {
      id: `${query.toLowerCase().replace(/\s/g, '-')}-official`,
      name: `${query} (Windows Official)`,
      developer: 'Verified Publisher',
      thumbnail: `https://ui-avatars.com/api/?name=${query}&background=0D1117&color=fff&size=512`,
      downloadUrl: `https://winget.run/pkg/Publisher/${query}`,
      platform: 'pc',
      isFOSS: false,
      installScript: `winget install --id "Publisher.${query}" -e --accept-package-agreements`
    }
  ];
};

// ==========================================
// API ENDPOINTS
// ==========================================

// A. Autocomplete API (Live Suggestions)
app.get('/api/autocomplete', async (req: Request, res: Response) => {
  const { q, platform } = req.query;
  if (!q || typeof q !== 'string') return res.status(400).json({ error: 'Query required' });

  try {
    let suggestions: any[] = [];
    // Fetch only top 5 for quick autocomplete
    if (platform === 'ios') suggestions = await searchIOS(q, 5);
    else if (platform === 'android') suggestions = await searchAndroid(q, 5);
    else suggestions = await searchPC(q); // PC

    res.json({ success: true, data: suggestions });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Autocomplete failed' });
  }
});

// B. Deep Search API
app.get('/api/search', async (req: Request, res: Response) => {
  const { q, platform } = req.query;
  if (!q || typeof q !== 'string') return res.status(400).json({ error: 'Query required' });

  try {
    let results: any[] = [];
    if (platform === 'ios') results = await searchIOS(q, 15);
    else if (platform === 'android') results = await searchAndroid(q, 15);
    else results = await searchPC(q);

    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Search failed' });
  }
});

// C. Category Carousels API
app.get('/api/carousel', async (req: Request, res: Response) => {
  const { category, platform } = req.query;
  const term = category === 'social' ? 'Social Media' : 'Photo Video Editor';
  
  try {
    let results: any[] = [];
    if (platform === 'ios') results = await searchIOS(term, 15);
    else if (platform === 'android') results = await searchAndroid(term, 15);
    else results = await searchPC(term);

    res.json({ success: true, data: results });
  } catch (error) {
    res.status(500).json({ success: false, error: 'Carousel fetch failed' });
  }
});

app.listen(PORT, () => {
  console.log(`[🚀] Backend Engine running on http://localhost:${PORT}`);
});